class main1:
    def __init__(self,name,age,salary,name2):
        self.name=name
        self.age=age
        self.salary=salary
        self.name2=name2
class main2(main1):
    def clone(self):
        # super().__init__(self,name,age,salary)
        print(self.name,"is good boy","and",self.age,"years old",self.salary,"his salary")
    def clone1(self):
        print(self.name2)
obj1=main2("aadarsh",23,25000,"rocky")
obj2=main2("raju",30,30000,"man")
obj2.clone()