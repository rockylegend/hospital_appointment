from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(PatientDischargeDetails)
admin.site.register(Doctor)
@admin.register(Patient)
class PatientDoctor(admin.ModelAdmin):
    list_display = ["first_name","last_name","username1","password1","address","mobile"]
    
# admin.site.register(pending_users)
# admin.site.register(update_doctor)
admin.site.register(Department)
# admin.site.register(Appointment)

@admin.register(Appointment)
class AdminAppointment(admin.ModelAdmin):
    list_display = ["id", "doctorName","patientName", "appointmentDate", "description", "status"]  
