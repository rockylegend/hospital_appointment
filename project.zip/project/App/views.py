from django.contrib.auth import login,authenticate,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.shortcuts import render,redirect,reverse
from django.contrib.auth.models import User,auth
from datetime import datetime,timedelta,date
from django.contrib import messages
from .models import *
from . import forms
# Create your views here.
def home(request):
    if request.method=='POST':
        inp1=request.POST['username']
    return render(request,'index.html')

def adminclick_view(request):
    return render(request,'adminclick.html')

def doctorclick_view(request):
    return render(request,'doctorclick.html')

def patientclick_view(request):
    return render(request,'patientclick.html')

def admin_login_view(request):
    if request.method=='POST':
        var1=request.POST['username']
        var2=request.POST['password']
        var3=authenticate(username=var1,password=var2)
        if var3 is not None:
            login(request,var3)
            return render(request,'admin_dashboard.html')
        else:
            messages.success(request,"incorrect username and password !")
    else:
        messages.success(request,"incorrect username and password !")
    return render(request,'adminlogin.html')


def doctor_login_view(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        # Doctor.objects.get(username=var1)
        # Doctor.objects.get(password=var2)
        user=Doctor(request,username=username,password=password)
        # user.save()
        print(user)
        try:
            auth=authenticate(username=username,password=password)
            if auth is not None:
                login(request,auth)
                return redirect('doctor_approval')
            else:
                return redirect('doctor-dashboard')
        except:
            print("Doctor Doesnot exists")
    return render(request,'doctorlogin.html')

def patient_signup_view(request):
    department=Department.objects.all()
    if request.method=='POST':
        val1=request.POST['first_name']
        val2=request.POST['last_name']
        val3=request.POST['username']
        val4=request.POST['password']
        val5=request.POST['address']
        val6=request.POST['phone']
        val7=request.POST['department']
       
        main=Patient(first_name=val1,last_name=val2,username1=val3,password1=val4,address=val5,mobile=val6, department=val7)
        # user=User(username=val1,password=val4)
        # user.save()
        main.save()
         
        createuser=User.objects.create_user(username=val3,password=val4)
        createuser.save()
        return redirect("patientlogin")
    return render(request,'patientsignup.html',{'department':department})


def patient_login_view(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        print(username,password)
        user1=Patient(request,username1=username,password1=password)
        print(user1)
        try :
            Patient.objects.get(username1=username)
            Patient.objects.get(password1 = password)
            auth=authenticate(username=username,password=password)
            if auth is not None:
                login(request,auth)
                return redirect('patient_approval')
        except:
            HttpResponseRedirect("User Doesnot exists")
        return redirect('patient_approval')
    return render(request,'patientlogin.html')
       

def admin_doctor_view(request):
    return render(request,'admin_doctor.html')

def admin_patient_view(request):
    return render(request,'admin_patient.html')

def admin_view_patient_view(request):
    patients=Patient.objects.all()
    dep=Department.objects.all()
    return render(request,'admin_view_patient.html',{'patients':patients,'dep':dep})

def admin_view_doctor_view(request):
    doctors=Doctor.objects.all()
    dep=Department.objects.all()
    return render(request,'admin_view_doctor.html',{'doctors':doctors,'dep':dep})


def update_doctor_view(request,id):
    update_d=Department.objects.all()
    if request.method=='POST':
        upd1=request.POST['name']
        upd2=request.POST['username']
        upd3=request.POST['contact']
        upd4=request.POST['department']
        upd5=request.POST['password']
        upd6=request.POST['address']

        doctor = Doctor.objects.get(id=id)
        doctor.first = upd1
        doctor.username = upd2
        doctor.mobile = upd3
        doctor.department = upd4
        doctor.password = upd5
        doctor.address = upd6
        
        doctor.save()
        return redirect('admin-view-doctor')
    d = Doctor.objects.get(id=id)
    return render(request,'admin_update_doctor.html', context={'d':d,'update_d':update_d})


def update_patient_view(request,username1):
    update_d=Department.objects.all()
    if request.method=='POST':
        upd1=request.POST['first_name']
        upd2=request.POST['username']
        upd3=request.POST['contact']
        upd4=request.POST['department']
        upd5=request.POST['password']
        upd6=request.POST['address']
        upd7=request.POST['last_name']
        
        p = Patient.objects.get(username1=username1)
        p.first_name = upd1
        p.username1 = upd2
        p.mobile = upd3
        p.department = upd4
        p.password1 =upd5
        p.address = upd6
        p.last_name = upd7
        p.save()
        return redirect('admin-view-patient')
    p = Patient.objects.get(username1=username1)
    return render(request,'admin_update_patient.html',context={'p':p,'update_d':update_d})

def delete_patient_from_hospital_view(request,username1):
    try:
        patient=Patient.objects.get(username1 = username1)
        patient.delete()
        return render(request,'admin_view_patient.html')
    except:
        print('DELETE')

def delete_doctor_from_hospital_view(request,id):
    try:
        doctor = Doctor.objects.get(id=id)
        doctor.delete()
        return render(request,'admin_view_doctor.html')
    except:
        print('DELETE')


def admin_add_doctor(request):
    dep=Department.objects.all()
    if request.method=='POST':
        val1=request.POST['first_name']
        val2=request.POST['department']
        val3=request.POST['username']
        val4=request.POST['password']
        val5=request.POST['address']
        val6=request.POST.get('Contact')

        user=Doctor(first=val1,department=val2,username=val3,password=val4,address=val5,mobile=val6)
        user.save()
        createuser=User.objects.create_user(username=val3,password=val4)
        createuser.save()
        return redirect('admin-view-doctor')
    return render(request,'admin_add_doctor.html',{'dep':dep})

def admin_add_patient(request):
    dep=Department.objects.all()
    if request.method=='POST':
        val1=request.POST['first_name']
        val2=request.POST['department']
        val3=request.POST['username']
        val4=request.POST['password']
        val5=request.POST['address']
        val6=request.POST['last_name']
        val7=request.POST['Contact']

        add=Patient(first_name=val1,department=val2,last_name=val6,username1=val3,password1=val4,address=val5,mobile=val7)
        add.save()
        userdata=User.objects.create_user(username=val3,password=val4)
        userdata.save()
        return redirect('admin-view-patient')
    return render(request,'admin_add_patient.html',{'dep':dep})


def admin_approve_doctor_view(request):
    doctors=Doctor.objects.all().filter(status=False)
    return render(request,'admin_approve_doctor.html',{'doctors':doctors})


def approve_doctor_view(request,id):
    doctor=Doctor.objects.get(id=id)
    doctor.status=True
    doctor.save()
    return redirect(reverse('admin_approve_doctor'))

def reject_doctor_view(request,pk):
    doctor=Doctor.objects.get(id=pk)
    doctor.delete()
    return redirect('admin_approve_doctor')


def admin_approve_patient_view(request):
    patients=Patient.objects.all().filter(status=False)
    return render(request,'admin_approve_patient.html',{'patients':patients})

def approve_patient_view(request,username1):
    patient=Patient.objects.get(username1=username1)
    patient.status=True
    patient.save()
    return redirect(reverse('admin_approve_patient'))

def reject_patient_view(request,username1):
    patient=Patient.objects.get(username1=username1)
    patient.delete()
    return redirect('admin_approve_patient')

def admin_view_doctor_specialisation_view(request):
    doctors=Doctor.objects.all()
    return render(request,'admin_view_doctor_specialisation.html',{'doctors':doctors})


def admin_discharge_patient_view(request):
    patients=Patient.objects.all().filter(status=True)
    return render(request,'admin_discharge_patient.html',{'patients':patients})

def doctor_view_discharge_patient_view(request):
    dischargedpatients=PatientDischargeDetails.objects.all().distinct()
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    return render(request,'doctor_view_discharge_patient.html',{'dischargedpatients':dischargedpatients,"doctor":man})

def discharge_patient_view(request,username1):
    patient=Patient.objects.get(username1=username1)
    days=(date.today()-patient.admitDate) #2 days, 0:00:00
    assignedDoctor=Appointment.objects.all()
    doctor = Appointment.objects.get(patientName=patient.first_name,status=True)
    print(doctor)
    d=days.days # only how many day that is 2
    patientDict={
        'patientId':username1,
        'name':patient.first_name,
        'mobile':patient.mobile,
        'address':patient.address,
        'description':Appointment.description,
        'admitDate':patient.admitDate,
        'todayDate':date.today(),
        'day':d,
        'assignedDoctorName':doctor.doctorName,
    }
    if request.method == 'POST':
        feeDict ={
            'roomCharge':int(request.POST['roomCharge'])*int(d),
            'doctorFee':request.POST['doctorFee'],
            'medicineCost' : request.POST['medicineCost'],
            'OtherCharge' : request.POST['OtherCharge'],
            'total':(int(request.POST['roomCharge'])*int(d))+int(request.POST['doctorFee'])+int(request.POST['medicineCost'])+int(request.POST['OtherCharge'])
        }
        patientDict.update(feeDict)
        #for updating to database patientDischargeDetails (pDD)
        pDD=PatientDischargeDetails()
        # aDD=Appointment()
        # pPP=Patient()
        # pPP.username1=Patient.username1
        # pDD.patientName=patient.first_name
        # pDD.assignedDoctorName=Doctor.first
        # pDD.address=patient.address
        # pDD.mobile=patient.mobile
        # aDD.description=Appointment.description
        # pDD.admitDate=patient.admitDate
        # pDD.releaseDate=date.today()
        pDD.daySpent=int(d)
        pDD.medicineCost=int(request.POST['medicineCost'])
        pDD.roomCharge=int(request.POST['roomCharge'])*int(d)
        pDD.doctorFee=int(request.POST['doctorFee'])
        pDD.OtherCharge=int(request.POST['OtherCharge'])
        pDD.total=(int(request.POST['roomCharge'])*int(d))+int(request.POST['doctorFee'])+int(request.POST['medicineCost'])+int(request.POST['OtherCharge'])
        pDD.save()
        return render(request,'patient_final_bill.html',context=patientDict)
    return render(request,'patient_generate_bill.html',context=patientDict)
import io
from django.template.loader import get_template
from django.template import Context
from xhtml2pdf import pisa
from django.http import HttpResponse

def render_to_pdf(template_src, context_dict):
    template = get_template(template_src)
    html  = template.render(context_dict)
    result = io.BytesIO()
    pdf = pisa.pisaDocument(io.BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return

def download_pdf_view(request,first_name):

    dischargeDetails=PatientDischargeDetails.objects.all().filter(patientName=first_name)
   
    dict={
        'patientName':dischargeDetails[0].patientName,
        'assignedDoctorName':dischargeDetails[0].assignedDoctorName,
        'address':dischargeDetails[0].address,
        'mobile':dischargeDetails[0].mobile,
        # 'symptoms':dischargeDetails[0].symptoms,
        'admitDate':dischargeDetails[0].admitDate,
        'releaseDate':dischargeDetails[0].releaseDate,
        'daySpent':dischargeDetails[0].daySpent,
        'medicineCost':dischargeDetails[0].medicineCost,
        'roomCharge':dischargeDetails[0].roomCharge,
        'doctorFee':dischargeDetails[0].doctorFee,
        'OtherCharge':dischargeDetails[0].OtherCharge,
        'total':dischargeDetails[0].total,
    }
    return render_to_pdf('download_bill.html',dict)
    # return render(request, 'admin_dashboard.html')

def admin_appointment_view(request):
    return render(request,'admin_appointment.html')

def admin_add_appointment_view(request):
    error=""
    d_appo=Doctor.objects.all()
    p_appo=Patient.objects.all()
    if request.method=='POST':
        appo1=request.POST['d_appo']
        appo2=request.POST['p_appo']
        appo3=request.POST['description']
        try:
            appointment=Appointment(doctorName=appo1,patientName=appo2,description=appo3)
            appointment.save()
            error="no"
        except:
            error="yes"
        return redirect('admin-view-appointment')
    return render(request,'admin_add_appointment.html',{'d_appo':d_appo,'p_appo':p_appo})

def admin_view_appointmentview(request):
    appointments=Appointment.objects.all()
    return render(request,'admin_view_appointment.html',{'appointments':appointments})


def patient_book_appointment_view(request):
    return render(request,'patient_book_appointment.html') 


def patient_wait_approval(request):
    # patient=Patient.objects.all()
    # doctor=Doctor.objects.all()
    # # if is_admin(request.):
    # #     return redirect('admin-dashboard')
    # if doctor is not None:
    #     accountapproval=Doctor.objects.all().filter(status=True)
    #     if accountapproval:
    #         return redirect('doctor-dashboard')
    #     else:
    #         return render(request,'doctor_wait_for_approval.html')
    # elif patient is not None:
    #     accountapproval=Patient.objects.all().filter(status=True)
    #     if accountapproval:
    #         return redirect('patient-dashboard')
    #     else:
    #         # return render(request,'hospital/patient_wait_for_approval.html')
    #         return render(request,'patient_wait_for_approval.html')
    var=request.user
    patientdata=Patient.objects.filter(username1=var)
    var2=patientdata.values()
    for statuscheck in var2:
        var3=statuscheck.get('status')
        if var3==True:
            print(var3)
            return redirect('patient-dashboard1')
        else:
            return render(request,'patient_wait_for_approval.html')

def doctor_wait_approval(request):
    var=request.user
    print(var,"1")
    doctordata=Doctor.objects.filter(username=var)
    print(doctordata)
    var2=doctordata.values()
    print(var2,"2")
    for statuscheck in var2:
        var3=statuscheck.get('status')
        print(var3,"3")
        if var3==True:
            print(var3,"4")
            return redirect('doctor-dashboard')
        else:
            return render(request,'doctor_wait_for_approval.html')

def admin_approve_appointment_view(request):
    approve=Appointment.objects.all().filter(status=False)
    return render(request,'admin_approve_appointment.html',{'approve':approve})

def approve_appointment_view(request,pk):
    appointment=Appointment.objects.get(id=pk)
    appointment.status=True
    appointment.save()
    return redirect(reverse('admin_approve_appointment'))

def reject_appointment_view(request,pk):
    appointment=Appointment.objects.get(id=pk)
    appointment.delete()
    return redirect('admin-approve-appointment')

def doctor_patient_view(request):
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    # doctor=Doctor.objects.get(id=id)
    return render(request,'doctor_patient.html',{"doctor":man})

def doctor_appointment_view(request):
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    # doctor=models.Doctor.objects.get(user_id=request.user.id)
    return render(request,'doctor_appointment.html',{"doctor":man})

def doctor_view_patient_view(request):
    patients=Patient.objects.all().filter(status=True)
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    # doctor=Doctor.objects.get()
    return render(request,'doctor_view_patient.html',{'patients':patients,"doctor":man})

def doctor_view_appointment_view(request):
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    appointments=Appointment.objects.all().filter(status=True)
    # patientid=[]
    # for a in appointments:
    #     patientid.append(a.patientName)
    patients=Patient.objects.all().filter(status=True)
    appointments=zip(appointments,patients)
    return render(request,'doctor_view_appointment.html',context={'appointments':appointments,'doctor':man})

def doctor_delete_appointment_view(request):
    doctor=Doctor.objects.all().values()
    for i in doctor:
        man=i.get('first')
    appointments=Appointment.objects.all().filter(status=True)

    # patientid=[]
    # for a in appointments:
    #     patientid.append(a.patientName)
    patients=Patient.objects.all().filter(status=True)
    appointments=zip(appointments,patients)
    return render(request,'doctor_delete_appointment.html',{'appointments':appointments,'doctor':man})

def delete_appointment_view(request,pk):
    appointment=Appointment.objects.get(id=pk)
    appointment.delete()
    doctor=Doctor.objects.all()
    print(doctor)
    var=doctor.values()
    print(var)
    for i in doctor:
        man=i.get('first')
    appointments=Appointment.objects.all().filter(status=True)
    # patientid=[]
    # for a in appointments:
    #     patientid.append(a.patientId)
    patients=Patient.objects.all().filter(status=True)
    appointments=zip(appointments,patients)
    return render(request,'doctor_delete_appointment.html',{'appointments':appointments,'doctor':man})

def patient_dashboard_view(request):
    userdata=request.user
    print(userdata)
    patient=Patient.objects.filter(username1=userdata)
    patientData=patient.values()
    print(patientData)
    for i in patientData:
        print(i.get('first_name'))
    # doctor=Doctor.objects.all()
        # mydict={
        # 'patient':i.get('first_name'),
        # # 'doctorName':doctor.first,
        # # 'doctorMobile':doctor.mobile,
        # # 'doctorAddress':doctor.address,
        # # # 'symptoms':patient.symptoms,
        # # 'doctorDepartment':doctor.department,
        # 'admitDate':i.get('admitDate'),
        # }
        patientName=i.get('first_name')
        admit_Date=i.get('admitDate')
    doctor=Appointment.objects.filter(patientName=i.get('first_name'))
    print(doctor.values())
    for j in doctor.values():
        doc_Name=j.get('doctorName')
        symptum=j.get('description')
    doctor_Detail=Doctor.objects.filter(first=j.get('doctorName'))
    for k in doctor_Detail.values():
        D_Name=k.get('first')
        mobile=k.get('mobile')
        address=k.get('address')
        department=k.get('department')
    
    return render(request,'patient_dashboard.html',{'patient':patientName,'admitDate':admit_Date,'doc_Name':doc_Name,'symptum':symptum,'doctorName':D_Name,'doctorMobile':mobile,'doctorAddress':address,'doctorDepartment':department})


def doctor_dashboard_view(request):
    userdata=request.user
    doctor=Doctor.objects.filter(username=userdata)
    doctorData=doctor.values()
    # print(doctorData,"d_name1")
    for k in doctorData:
        doctorName1=k.get('first')
        symptum=k.get('description')
        # print(doctorName1,"d_name2")
    patientid=[]
    patientcount=Patient.objects.all().filter(status=True).count()
    appointmentcount=Appointment.objects.all().filter(status=True).count()
    # patientdischarged=PatientDischargeDetails.objects.all().distinct().count()
    appointments=Appointment.objects.all().filter(status=True)
    print(appointments.values())
    patients=Patient.objects.all().filter(status=True)
    
    for a in appointments:
        patientid.append(a.patientName)
    appointments=zip(appointments,patientid, patients)
    mydict={
    'patientcount':patientcount,
    'appointmentcount':appointmentcount,
    # 'patientdischarged':patientdischarged,
    'appointments':appointments,
    'doctor':doctorName1,
    'symptum':symptum,
    'patient':patients,
    }
    print(appointments,"name")
    print(patients)
    return render(request,'doctor_dashboard.html',context=mydict)

def admin_dashboard_view(request):
    patients=Patient.objects.all()
    doctors=Doctor.objects.all()
    doctorcount=Doctor.objects.all().filter(status=True).count()
    pendingdoctorcount=Doctor.objects.all().filter(status=False).count()

    patientcount=Patient.objects.all().filter(status=True).count()
    pendingpatientcount=Patient.objects.all().filter(status=False).count()

    appointmentcount=Appointment.objects.all().filter(status=True).count()
    pendingappointmentcount=Appointment.objects.all().filter(status=False).count()

    return render(request,'admin_dashboard.html',{'patients':patients,'doctors':doctors,'doctorcount':doctorcount,'pendingdoctorcount':pendingdoctorcount,'patientcount':patientcount,'pendingpatientcount':pendingpatientcount,'appointmentcount':appointmentcount,'pendingappointmentcount':pendingappointmentcount})

def patient_generate_bill_view(request):
    return render(request,'patient_generate_bill.html')

def patient_final_bill_view(request):
    return render(request,'patient_final_bill.html')

def contactus_view(request):
    return render(request,'contactus.html')

def Logout_page(request):
    logout(request)
    return redirect('home')