from django.urls import path
from App import views
from django.contrib.auth.views import LoginView

urlpatterns = [
    path('',views.home,name='home'),
    path('adminclick',views.adminclick_view,name='adminclick'),
    path('doctorclick',views.doctorclick_view,name='doctorclick'),
    path('patientclick',views.patientclick_view, name="patientclick"),

    path('adminlogin',views.admin_login_view,name="adminlogin"),
    path('doctorlogin',views.doctor_login_view,name="doctorlogin"),
    path('patientsignup',views.patient_signup_view,name='patientsignup'),
    path('patientlogin',views.patient_login_view,name='patientlogin'),

    path('patient_approval',views.patient_wait_approval,name='patient_approval'),
    path('doctor_approval',views.doctor_wait_approval,name='doctor_approval'),

    path('admin-dashboard',views.admin_dashboard_view,name='admin-dashboard'),
    path('patient-dashboard', views.patient_dashboard_view,name='patient-dashboard1'),
    path('doctor-dashboard',views.doctor_dashboard_view,name='doctor-dashboard'),

    path('doctor-patient', views.doctor_patient_view,name='doctor-patient'),
    path('doctor-appointment', views.doctor_appointment_view,name='doctor-appointment'),
    path('doctor-view-patient', views.doctor_view_patient_view,name='doctor-view-patient'),
    path('doctor-view-appointment', views.doctor_view_appointment_view,name='doctor-view-appointment'),
    path('doctor-delete-appointment',views.doctor_delete_appointment_view,name='doctor-delete-appointment'),
    path('delete-appointment/<int:pk>', views.delete_appointment_view,name='delete-appointment'),

    path('admin_doctor',views.admin_doctor_view,name='admin_doctor'),
    path('admin_patient/',views.admin_patient_view,name='admin_patient'),

    path('admin-view-doctor',views.admin_view_doctor_view,name='admin-view-doctor'),
    path('admin-view-patient/',views.admin_view_patient_view,name='admin-view-patient'),

    path('update_doctor/<int:id>',views.update_doctor_view,name='update_doctor'),
    path('update_patient/<str:username1>/',views.update_patient_view,name='update_patient'),
    path('delete-patient/<str:username1>/',views.delete_patient_from_hospital_view,name='delete-patient'), 
    path('delete-doctor/<int:id>',views.delete_doctor_from_hospital_view,name='delete-doctor'),
    
    path('admin_add_doctor',views.admin_add_doctor,name='admin_add_doctor'),
    path('admin_add_patient',views.admin_add_patient,name='admin_add_patient'),
    path('admin_add_appointment',views.admin_add_appointment_view,name='admin_add_appointment'),

    path('admin_approve_doctor',views.admin_approve_doctor_view,name='admin_approve_doctor'),
    path('approve-doctor/<int:id>',views.approve_doctor_view,name='approve-doctor'),
    path('reject-doctor/<int:pk>',views.reject_doctor_view,name='reject-doctor'),
    path('admin_approve_patient',views.admin_approve_patient_view,name='admin_approve_patient'),
    path('approve_patient/<str:username1>',views.approve_patient_view,name='approve_patient'),
    path('reject-patient/<str:username1>',views.reject_patient_view,name='reject-patient'),

    path('admin_discharge_patient',views.admin_discharge_patient_view,name='admin_discharge_patient'),
    path('discharge-patient/<str:username1>',views.discharge_patient_view,name='discharge-patient'),
    path('admin-appointment', views.admin_appointment_view,name='admin-appointment'),
    path('admin-view-appointment',views.admin_view_appointmentview,name='admin-view-appointment'),
    path('doctor-view-discharge-patient',views.doctor_view_discharge_patient_view,name='doctor-view-discharge-patient'),
    
    path('patient_book_appointment',views.patient_book_appointment_view,name='patient_book_appointment_view'),
    path('admin_approve_appointment',views.admin_approve_appointment_view,name='admin_approve_appointment'),
    path('reject-appointment/<int:pk>', views.reject_appointment_view,name='reject-appointment'),
    path('approve-appointment/<int:pk>',views.approve_appointment_view,name='approve-appointment'),
    path('admin-view-doctor-specialisation',views.admin_view_doctor_specialisation_view,name='admin-view-doctor-specialisation'),
    path('download_pdf/<str:first_name>', views.download_pdf_view,name='download_pdf'),
    path('patient_generate_bill',views.patient_generate_bill_view,name='patient_generate_bill'),
    path('patient_final_bill',views.patient_final_bill_view,name='patient_final_bill'),
    path('Logout',views.Logout_page,name='Logout'),
    path('contactus',views.contactus_view,name='contactus'),
]