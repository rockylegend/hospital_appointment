from django.db import models
from django.contrib.auth.models import User
# Create your models here.

# departments=[('Cardiologist','Cardiologist'),
# ('Dermatologists','Dermatologists'),
# ('Emergency Medicine Specialists','Emergency Medicine Specialists'),
# ('Allergists/Immunologists','Allergists/Immunologists'),
# ('Anesthesiologists','Anesthesiologists'),
# ('Colon and Rectal Surgeons','Colon and Rectal Surgeons')
# ]
class Doctor(models.Model):
    first = models.CharField(max_length=100,null=True)
    last = models.CharField(max_length=100,null=True)
    username = models.CharField(max_length=60,default="aadarsh1")
    password = models.CharField(default=None,max_length=122)
    address = models.CharField(max_length=60,null=True)
    mobile = models.IntegerField(blank=True)
    department = models.CharField(max_length=50,null=True)
    status=models.BooleanField(default=False)
    
    def __str__(self):
        return str(self.first)


class Patient(models.Model):
    first_name = models.CharField(max_length=200,null=True)
    last_name = models.CharField(max_length=200,null=True)
    username1 = models.CharField(max_length=100,primary_key=True)
    password1 = models.CharField(default=None,max_length=122)
    address = models.CharField(max_length=80,null=True)
    mobile = models.CharField(max_length=20,null=False)
    department = models.CharField(max_length=50,null=True)
    admitDate=models.DateField(auto_now=True)
    status=models.BooleanField(default=False)
    def __str__(self):
        return str(self.first_name)
    

# class pending_users(models.Model):
#     first_name = models.CharField(max_length=200,null=True)
#     last_name=models.CharField(max_length=200,null=True)
#     username = models.CharField(max_length=100,primary_key=True)
#     password = models.CharField(default=None,max_length=122)
#     address = models.CharField(max_length=80,null=True)
#     mobile = models.CharField(max_length=20,null=False)
#     status=models.BooleanField(default=False)


# class update_doctor(models.Model):
#     doctor=models.CharField(max_length=120,null=True)
#     department=models.CharField(max_length=120,null=True)
#     username=models.CharField(max_length=120,null=True)
#     password = models.CharField(default=None,max_length=120)
#     address = models.CharField(max_length=80,null=True)
#     mobile = models.CharField(max_length=20,null=False)
#     status=models.BooleanField(default=False)
#     def __str__(self):
#         return str(self.doctor)
    

class Appointment(models.Model):
    # patientId=models.PositiveIntegerField(null=True)
    # doctorId=models.PositiveIntegerField(null=True)
    patientName=models.CharField(max_length=40,null=True)
    doctorName=models.CharField(max_length=40,null=True)
    appointmentDate=models.DateField(auto_now=True)
    description=models.TextField(max_length=500)
    status=models.BooleanField(default=False)

class PatientDischargeDetails(models.Model):
    patientId=models.PositiveIntegerField(null=True)
    patientName=models.CharField(max_length=40)
    assignedDoctorName=models.CharField(max_length=40)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=True)
    # symptoms = models.CharField(max_length=100,null=True)

    admitDate=models.DateField(null=False)
    releaseDate=models.DateField(null=False)
    daySpent=models.PositiveIntegerField(null=False)

    roomCharge=models.PositiveIntegerField(null=False)
    medicineCost=models.PositiveIntegerField(null=False)
    doctorFee=models.PositiveIntegerField(null=False)
    OtherCharge=models.PositiveIntegerField(null=False)
    total=models.PositiveIntegerField(null=False)
    def __str__(self):
        return str(self.admitDate)
    
    
class Department(models.Model):
    department=models.CharField(max_length=120)
    def __str__(self):
        return self.department